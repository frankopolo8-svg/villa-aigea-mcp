# Hotel Brain MCP Server

Έτοιμο demo πακέτο για να συνδεθεί ο αλγόριθμος HotelBrain με το OpenAI Agent Builder.

## Εργαλεία MCP

- `get_daily_briefing`
- `get_top_priorities`
- `check_room_readiness`
- `find_guest_recovery_cases`
- `find_upsell_opportunities`
- `get_vip_arrivals`
- `get_maintenance_issues`
- `ask_hotel_brain`

## Γρήγορη φιλοξενία σε Replit

1. Δημιούργησε νέο Python Repl.
2. Ανέβασε όλα τα αρχεία αυτού του φακέλου.
3. Άνοιξε Shell και εκτέλεσε:

```bash
pip install -r requirements.txt
python hotel_brain_mcp_server.py
```

4. Άνοιξε το δημόσιο web URL του Repl.
5. Στο Agent Builder βάλε το URL με κατάληξη:

```text
https://ΤΟ-ΔΗΜΟΣΙΟ-DOMAIN/mcp
```

6. Για αυτό το demo διάλεξε προσωρινά **χωρίς πιστοποίηση**, επειδή τα δεδομένα είναι φανταστικά.
7. Μετά τη σύνδεση, επίλεξε τα εργαλεία που θα επιτρέπονται στον MCP κόμβο.

## Σημαντικό

Το `https://to-domain-mas/mcp` είναι placeholder και δεν μπορεί να λειτουργήσει.
Το URL πρέπει να προέρχεται από server που τρέχει πραγματικά και είναι προσβάσιμος με HTTPS.

## Τοπική δοκιμή

```bash
pip install -r requirements.txt
python hotel_brain_mcp_server.py
```

Τοπικά ο server ξεκινά στην πόρτα 8000 και το MCP endpoint είναι `http://localhost:8000/mcp`. Το Agent Builder δεν μπορεί να
προσπελάσει το `localhost`, γι’ αυτό απαιτείται δημόσια φιλοξενία ή ασφαλές tunnel.

## Παραγωγή

Πριν χρησιμοποιηθούν πραγματικά δεδομένα επισκεπτών:

- πρόσθεσε OAuth ή ισχυρό authentication,
- κράτησε ανθρώπινη έγκριση για write actions,
- μην αποθηκεύεις ευαίσθητα στοιχεία σε logs,
- αντικατάστησε το demo JSON με ασφαλή PMS/API integration.
